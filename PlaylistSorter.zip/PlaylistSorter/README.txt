Matthew Chin
This program reads in a Playlist text file and sorts it by year and artist using mergesort and quicksort.
Run jar with
java -jar Playlist.jar PartyMix.txt
